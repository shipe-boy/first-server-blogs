//专门处理路由
const Router = require("koa-router"); //路由
const router = new Router;

//处理根路由
router.get("/", async (ctx) => {
    /* await ctx.render("index", {
        session : {
            avatar : "/avatar/img1.jpg"
        }
    }); */
    await ctx.render("index");
});
/* 
    /user/login
    /user/reg
*/
//处理注册和登录页面
router.get(/^\/user\/(reg|login)/, async (ctx) => {
    //得到布尔值， true显示注册， false显示登录
    const show = /(reg)$/.test(ctx.path);
    // await ctx.render("register", {show : show});
    await ctx.render("register", {show});
});

//注册





//导出
module.exports = router;

