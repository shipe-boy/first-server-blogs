const User = require("../module/user"); //得到操控集合的对象
const crypto = require("../utils/encrypt"); //得到加密的方法

//处理用户注册的中间件
exports.reg = async (ctx) => {
    // console.log("乌拉拉");
    //得到post发过来的数据  得到用户名和密码
    let {username, password} = ctx.request.body;
    
    // console.log(crypto(password));
    await new Promise((res, rej) => {
        //先去数据库user集合查询是否有同名
        User.find({username}, (err, data) => {
            // 查询报错了
            if(err) return rej(err); //报错，传递失败状态和错误对象

            //查询中没报错,但是找到同名的数据了
            if(data.length !== 0) return res("");

            //查询中没报错，并且没有找到同名的数据,可以注册
            const userobj = new User({
                username,
                password : crypto(password),  //加密的密码
            });
            
            //将数据保存到数据库
            userobj.save((err, data) => {

            });
        });
    });

};