/*  koa
    koa-views
    pug
    koa-router
    koa-static
    koa-logger  日志
 */

 const Koa = require("koa");
 const static = require("koa-static"); //静态资源
 const views = require("koa-views"); //视图
 const router = require("./routers/router"); //路由
 const logger = require("koa-logger"); //日志模块
 const {join} = require("path"); //得到join
 const body = require("koa-body"); //得到解析post请求数据的模块
 const session = require("koa-session"); //得到session模块

//得到koa的实例
const app = new Koa;

app.keys = ["emmmmm"];

//session 的配置对象
const CONFIG = {
    key: 'sessionId',
    maxAge : 1000*60*60,
    overwrite: true,
    httpOnly: true,
    // signed: true,
};

//注册中间件
app
    .use(logger()) //注册日志 中间件
    .use(session(CONFIG, app))  //注册session
    .use(body())  //注册post解析数据的中间件
    .use(static(join(__dirname, "public"))) //设置静态资源的根目录
    .use(views(join(__dirname, "views"), {
        extension : "pug"   //告诉它我用的是pug模板引擎
    })); //设置视图模板根目录
    

//注册路由信息
app
    .use(router.routes())
    .use(router.allowedMethods());

//监听端口
app.listen(3000, () => {
    console.log("项目启动，开始监听3000端口");
});

