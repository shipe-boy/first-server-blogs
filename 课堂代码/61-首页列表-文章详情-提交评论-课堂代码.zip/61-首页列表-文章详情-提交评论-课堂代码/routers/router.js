//专门处理路由
const Router = require("koa-router"); //路由
const router = new Router;
const user = require("../control/user"); //
const article = require("../control/article"); //
const comment = require("../control/comment"); //

//处理根路由
 router.get("/", user.keepLogin, article.getList);//async (ctx) => {
//     /* await ctx.render("index", {
//         session : {
//             avatar : "/avatar/img1.jpg"
//         }
//     }); */
//     await ctx.render("index", {
//         session : ctx.session
//     });
// });
/* 
    /user/login
    /user/reg
*/
//处理注册和登录页面
router.get(/^\/user\/(reg|login)/, async (ctx) => {
    //得到布尔值， true显示注册， false显示登录
    const show = /(reg)$/.test(ctx.path);
    // await ctx.render("register", {show : show});
    await ctx.render("register", {show});
});

//处理用户注册的post请求     /user/reg
/* router.post("/user/reg", async (ctx) => {
    console.log("表单发起的post请求传过来的数据");
    console.log(ctx.request.body);
}); */
router.post("/user/reg", user.reg);

//处理用户登录的post请求 
router.post("/user/login", user.login);

//处理用户退出登录的路由请求
router.get("/user/logout", user.loginOut);

//点击跳转文章发表页面
router.get("/article", user.keepLogin, article.addPage);

//文章发表添加按钮请求路由处理
router.post("/article", user.keepLogin, article.add);

//处理文章列表路由
router.get("/page/:id", article.getList);
// /page/

//文章详情
router.get("/article/:id", user.keepLogin, article.details);

//提交评论
router.post("/comment", user.keepLogin, comment.publish);


//导出
module.exports = router;


