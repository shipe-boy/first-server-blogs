const Article = require("../module/article"); //得到操控Article集合的对象
//渲染文章发表页面
exports.addPage = async (ctx) => {
    await ctx.render("add-article", {
        session: ctx.session,
        title: "文章发表"
    });
};

//点击发表按钮， 接收数据，存储数据到文章表
exports.add = async (ctx) => {
    //用户没登录，提示请登录
    if (ctx.session.isNew) {
        //没登录
        return ctx.body = {
            status: 0,
            msg: "请登录"
        };
    }

    //取出发过来的数据
    let data = ctx.request.body;
    data.author = ctx.session.userId; //得到作者
    //ctx.session.userId
    await new Promise((res, rej) => {
        new Article(data)
            .save((err, data) => {
                if (err) return rej(err);
                res(data);
            })
    }).then(() => {
        ctx.body = {
            status: 1,
            msg: "发表成功"
        };
    }, () => {
        ctx.body = {
            status: 0,
            msg: "发表失败"
        };
    })
};

//