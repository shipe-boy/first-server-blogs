const User = require("../module/user"); //得到操控集合的对象
const crypto = require("../utils/encrypt"); //得到加密的方法

//处理用户注册的中间件
exports.reg = async (ctx) => {
    // console.log("乌拉拉");
    //得到post发过来的数据  得到用户名和密码
    let { username, password } = ctx.request.body;

    // console.log(crypto(password));
    await new Promise((res, rej) => {
        //先去数据库user集合查询是否有同名
        User.find({ username }, (err, data) => {
            // 查询报错了
            if (err) return rej(err); //报错，传递失败状态和错误对象

            //查询中没报错,但是找到同名的数据了
            if (data.length !== 0) return res("");

            //查询中没报错，并且没有找到同名的数据,可以注册
            const userobj = new User({
                username,
                password: crypto(password),  //加密的密码
            });

            //将数据保存到数据库
            userobj.save((err, data) => {
                if (err) {
                    rej("保存失败");
                } else {
                    res("保存成功");
                }
            });
        });
    }).then(async data => { //成功
        if (data) {
            //注册成功 ，渲染等待页,之后跳转登录页
            await ctx.render("isOk", {
                status: "regSuccess", //注册成功
                url: "/user/login"
            });
        } else {
            //空字符串，用户名已存在
            await ctx.render("isOk", {
                status: "regFail", //失败，用户已存在
                url: "/user/login"
            });
        }
    }, async err => { //失败
        await ctx.render("isOk", {
            status: "regError",
            url: "/user/reg"
        });
    });
};

//处理用户登录的中间件
exports.login = async (ctx) => {
    //得到post发过来的数据  得到用户名和密码
    let { username, password } = ctx.request.body;
    await new Promise((res, rej) => {
        //先去数据库user集合查询是否有同名
        User.find({ username }, (err, data) => {
            // 查询报错了
            if (err) return rej(err); //报错，传递失败状态和错误对象
            //查询中没报错,但是没查到数据
            if (data.length === 0) return rej(0);

            //用户名存在，比对密码是否一致
            //将用户传过来的密码加密，和数据库中中的加密密码进行比对
            if (data[0].password === crypto(password)) {
                return res(data);
            } else {
                return res(""); //查询到数据，但是密码没对
            }
        });

    }).then(async data => {
        if (data) {
            //登录成功
            await ctx.render("isOk", {
                status: "logSuccess", //登录成功
                url: "/"
            });

            //设置cookie
            ctx.cookies.set("username", username, {
                //配置cookie的属性
                domain: "localhost",
                path: "/",
                maxAge: 1000 * 60 * 60,
                httpOnly: true, //不让客户端操控这条cookie
                overwrite: false
            });

            //设置cookie
            ctx.cookies.set("userId", data[0]._id, {
                //配置cookie的属性
                domain: "localhost",
                path: "/",
                maxAge: 1000 * 60 * 60,
                httpOnly: true, //不让客户端操控这条cookie
                overwrite: false
            });

            //设置后台的session内的字段
            ctx.session = {
                username,
                userId: data[0]._id,
                avatar : data[0].avatar  //取到用户头像
            };

        } else {
            //密码错误，登录不成功
            await ctx.render("isOk", {
                status: "logError",
                url: "/user/login"
            });
        }
    }, async err => {
        if (err === 0) {
            //用户名不存在
            await ctx.render("isOk", {
                status: "logNot",
                url: "/user/reg"
            });
        } else {
            //其他错误
            await ctx.render("isOk", {
                status: "logFail",
                url: "/user/login"
            });
        }
    });
};

//确定用户状态的中间件
exports.keepLogin = async (ctx, next) => {
    //判断session是否存在
    // console.log(ctx.session.isNew);
    if (ctx.session.isNew) {
        //从未登录过
        if (ctx.cookies.get("userId")) {
            //cookie有，session 没有
            //更新一下session
            ctx.session = {
                username: ctx.cookies.get("username"),
                userId: ctx.cookies.get("userId"),
                
            };
        }
    }
    await next();
    /* 
        ctx.session = { isNew : true }
    */
};

// 退出登录
exports.loginOut = async (ctx) => {
    ctx.session = null;
    ctx.cookies.set("username", null, {
        maxAge: 0
    });
    ctx.cookies.set("userId", null, {
        maxAge: 0
    });
    // 重定向 到根路由 ---首页
    ctx.redirect("/");
};