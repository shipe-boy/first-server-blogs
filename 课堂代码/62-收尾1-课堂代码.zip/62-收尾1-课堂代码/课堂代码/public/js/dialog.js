layui.use("layer", function(){
    var layer = layui.layer;
    layer.msg(val);
});