const Article = require("../module/article"); //得到操控Article集合的对象
const User = require("../module/user");  //得到操控users集合对象
const Comment = require("../module/comment");
//渲染文章发表页面
exports.addPage = async (ctx) => {
    await ctx.render("add-article", {
        session: ctx.session,
        title: "文章发表"
    });
};

//点击发表按钮， 接收数据，存储数据到文章表
exports.add = async (ctx) => {
    //用户没登录，提示请登录
    if (ctx.session.isNew) {
        //没登录
        return ctx.body = {
            status: 0,
            msg: "请登录"
        };
    }

    //取出发过来的数据
    let data = ctx.request.body;
    data.author = ctx.session.userId; //得到作者
    //ctx.session.userId
    await new Promise((res, rej) => {
        new Article(data)
            .save((err, data) => {
                if (err) return rej(err);
                res(data);
            })
    }).then(() => {
        ctx.body = {
            status: 1,
            msg: "发表成功"
        };
    }, () => {
        ctx.body = {
            status: 0,
            msg: "发表失败"
        };
    })
};

//获取文章信息列表
exports.getList = async (ctx) => {
    let page = ctx.params.id || 1; //得到请求的页数
    let maxNum = await Article.estimatedDocumentCount((err, data) => {
        if(err) return err;
        return data;
    });
    let artList = await Article
        .find()
        .sort("-createTime")
        .skip((page-1) * 5)  //初始位置，跳过多少条
        .limit(5)  //获取多少条数据
        /* .populate({
            path : "author",
            select : "_id username avatar"
        }) */
        .populate("author", "_id username avatar")
        .then(data => data, err => {
            console.log("报错")
        });
    // console.log("乌拉拉",artList);

    //渲染页面
    await ctx.render("index", {
        session: ctx.session,
        title : "blog首页",
        artList,
        maxNum  //文章总数目
    });
};

//获取文章详情
exports.details = async (ctx) => {
    //获取动态路由中，文章的id
    let _id = ctx.params.id;

    let article = await Article
        .findById(_id)
        .populate("author", "username")
        .then(data => data, err => err);

    //评论用户名  头像  评论内容  评论时间  评论的哪篇文章
    
    //查找跟当前文章相关的所有评论
    let comment = await Comment
        .find({article: _id})
        .sort("-createTime")
        .populate("author", "username avatar")
        .then(data => data, err => {
            console.log("报错")
        });

    //渲染页面
    await ctx.render("article", {
        session: ctx.session,
        title : article.title,
        article,
        comment
    });
};

/* 
    文章  评论  头像  
    用户
*/
/* 
    find  返回数组，对象存在数组中
    [{}] [0]

    findById  返回单个对象
*/

// 1000
// 10 0-9
// 10 10-19 
// 20-29
// 动态路由
//   /page
// /page/1   0*10 = 0    10
// /page/2   1*10 = 10
// /page/1000 999*10