const Article = require("../module/article"); //得到操控Article集合的对象
const User = require("../module/user");  //得到操控users集合对象
const Comment = require("../module/comment");
const fs = require("fs");
const {join} = require("path");

exports.index = async (ctx) => {
    //用户没登录，提示请登录
    if (ctx.session.isNew) {
        //没登录
        ctx.status = 404;
        await ctx.render("404");
    }

    const id = ctx.params.id; //来自于谁
    const arr = fs.readdirSync(join(__dirname, "../views/admin"));
    // console.log(arr);

    let bool = false;

    arr.forEach(v => {
        let name = v.replace(/^(admin\-)|(\.pug)$/g, "");
        if(name === id){
           bool = true;
           return;
        }
    });
    console.log(bool);
    
    if(bool){
        await ctx.render("./admin/admin-" + id, {
            role : ctx.session.role
        });
    }else{
        ctx.status = 404;
        await ctx.render("404");
    }
}